package supermercado;

public class ProductoPrimeraNecesidad extends Producto {

    public ProductoPrimeraNecesidad(String nombre, Double precioBase, boolean esPreciosCuidados) {
        super(nombre, precioBase, esPreciosCuidados);
    }

    public ProductoPrimeraNecesidad(String nombre, Double precioBase) {
        super(nombre, precioBase);
    }

    @Override
    public Double getPrecio() {
        return super.getPrecio() * 0.9;
    }

}
