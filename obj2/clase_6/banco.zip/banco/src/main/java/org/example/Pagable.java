package org.example;

public interface Pagable {
    void recibirPago(double monto);
}
