package org.example;

public interface Garantia {
    String getDescripcion();
    String getDireccion();
    double getValorFiscal();
}
