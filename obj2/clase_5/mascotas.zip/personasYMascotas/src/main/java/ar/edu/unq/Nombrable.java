package ar.edu.unq;

public interface Nombrable {
    public String getNombre();
}
