package ar.edu.unq.po2;

public interface Agencia {
    public void registrarPago(Factura factura);
}
