package ar.edu.unq.po2;

public interface Pagable {
    public double getMonto();
    public void procesarPago();
}
