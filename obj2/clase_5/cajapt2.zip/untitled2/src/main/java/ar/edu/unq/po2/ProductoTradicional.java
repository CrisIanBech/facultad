package ar.edu.unq.po2;

public class ProductoTradicional extends Producto {

    public ProductoTradicional(int stock, double precioBase, String nombre) {
        super(stock, precioBase, nombre);
    }

}
