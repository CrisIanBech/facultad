package org.example;

public enum Color {
    ROJO, NEGRO
}
