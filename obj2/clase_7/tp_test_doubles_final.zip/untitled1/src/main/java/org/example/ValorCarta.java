package org.example;

public enum ValorCarta {
    UNO, DOS , TRES, CUATRO, CINCO, SEIS, SIETE, OCHO, NUEVE, DIEZ, J, Q, K;
}
