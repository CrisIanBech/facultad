package org.example;

public enum Combinacion {
    Nada, Trio, Color, Poquer
}
