package org.example;

public enum Palo {
    Picas, Corazones, Diamantes, Treboles
}
