package org.example.actividadsemanal;

public enum DiaDeLaSemana {
    LUNES, MARTES, MIERCOLES, JUEVES, VIERNES
}
