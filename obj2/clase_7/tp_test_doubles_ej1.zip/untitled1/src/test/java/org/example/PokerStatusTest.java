package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PokerStatusTest {

    @Test
    public void testCuatroCartasMismoPalo() {
        assertTrue(PokerStatus.verificar("10D", "QD", "5D", "6D", "5J"));
    }

    @Test
    public void testCartasDiferentes() {
        assertFalse(PokerStatus.verificar("10P", "QC", "5D", "6T", "5P"));
    }

    @Test
    public void testCincoCartasMismoPalo() {
        assertTrue(PokerStatus.verificar("10D", "QD", "5D", "6D", "5D"));
    }

    @Test
    public void testTresCartasMismoPalo() {
        assertFalse(PokerStatus.verificar("10D", "QD", "5D", "6T", "5C"));
    }

}