package org.example;

import java.util.HashSet;
import java.util.Set;

public class PokerStatus {

    public static boolean verificar(
        String primeraCarta, String segundaCarta, String terceraCarta, String cuartaCarta, String quintaCarta
    ) {
        Set<Character> unrepeatedCards = new HashSet<>();
        unrepeatedCards.add(paloDeCarta(primeraCarta));
        unrepeatedCards.add(paloDeCarta(segundaCarta));
        unrepeatedCards.add(paloDeCarta(terceraCarta));
        unrepeatedCards.add(paloDeCarta(cuartaCarta));
        unrepeatedCards.add(paloDeCarta(quintaCarta));
        return unrepeatedCards.size() <= 2;
    }

    private static Character paloDeCarta(String carta) {
        return carta.charAt(carta.length() - 1);
    }

}
